import base64
import binascii
import click
import lxml.etree as ET

from fido2.client import ClientError, Fido2Client
from fido2.hid import CtapHidDevice
from fido2.utils import websafe_decode, websafe_encode

try:
    from fido2.pcsc import CtapPcscDevice
except ImportError:
    CtapPcscDevice = None

import logging
import json
import platform
import re

from threading import Event, Thread

from .consts import (
    DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH,
    DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL,
    DUO_UNIVERSAL_PROMPT_FACTOR_WEBAUTHN,
    DUO_UNIVERSAL_PROMPT_FACTOR_PASSCODE,
)
from .helpers import trace_http_request

import time

try:
    # Python 3
    from urllib.parse import urlparse, parse_qs, quote
    import queue
except ImportError:
    # Python 2
    from urlparse import urlparse, parse_qs, quote
    import Queue as queue

from . import roles_assertion_extractor

_headers = {
    "Accept-Language": "en",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Accept": "text/plain, */*; q=0.01",
}

_json_headers = {
    "Accept-Language": "en",
    "Content-Type": "application/json",
    "Accept": "application/json, text/plain, */*",
}

# Minimal browser features for CLI (no touch/WebAuthn/platform authenticator)
_BROWSER_FEATURES = quote(json.dumps({
    "touch_supported": False,
    "platform_authenticator_status": "unavailable",
    "webauthn_supported": False,
    "screen_resolution_height": 1080,
    "screen_resolution_width": 1920,
    "screen_color_depth": 24,
    "is_uvpa_available": False,
    "client_capabilities_uvpa": None,
}, separators=(',', ':')))


class _OidcSession:
    """Carries new Duo Universal Prompt OIDC session state (uses authkey, no legacy sid)."""

    def __init__(self, authkey, akey, host, push_pkey=None, phone_pkey=None):
        self.authkey = authkey
        self.akey = akey
        self.host = host           # e.g. "https://api-f00161c8.duosecurity.com"
        self.push_pkey = push_pkey
        self.phone_pkey = phone_pkey

    @property
    def base_url(self):
        return f"{self.host}/prompt/{self.akey}"

    def pkey_for_factor(self, factor):
        if factor == DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH:
            return self.push_pkey
        if factor == DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL:
            return self.phone_pkey
        return None


def extract(html_response, ssl_verification_enabled, session, duo_factor, duo_device):
    """
    this strategy is based on description from: https://guide.duo.com/universal-prompt
    :param response: raw http response
    :param html_response: html result of parsing http response
    :return:
    """

    duo_url = _duo_url(html_response)
    adfs_context = _adfs_context(html_response)
    adfs_auth_method = _adfs_auth_method(html_response)
    roles_page_url = _action_url_on_validation_success(html_response)

    click.echo("Sending request for authentication", err=True)
    (
        sid,
        xsrf,
        preferred_factor,
        preferred_device,
        webauthn_supported,
        auth_signature,
        duo_url,
    ), initiated = _initiate_authentication(
        duo_url,
        adfs_context,
        adfs_auth_method,
        roles_page_url,
        session,
        ssl_verification_enabled,
    )
    if initiated:
        if auth_signature is not None:
            # Non-interactive auth already completed (e.g. Duo policy auto-approved)
            signed_response = auth_signature
        else:
            click.echo("Waiting for additional authentication", err=True)

            # Override preferred factor value if it the same as the device, which means WebAuthn
            if webauthn_supported and preferred_factor == preferred_device:
                preferred_factor = DUO_UNIVERSAL_PROMPT_FACTOR_WEBAUTHN

            # Prioritize configuration or command-line parameters factor and device over server-side preferred ones
            if duo_factor:
                preferred_factor = duo_factor
            if duo_device:
                preferred_device = duo_device

            if preferred_factor is None:
                click.echo("No default authentication method configured.")
                preferred_factor = click.prompt(
                    text=f'Please enter your desired authentication method (e.g. "{DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH}", "{DUO_UNIVERSAL_PROMPT_FACTOR_PASSCODE}", "{DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL}", or "{DUO_UNIVERSAL_PROMPT_FACTOR_WEBAUTHN}")',
                    type=str,
                )

            # In case of WebAuthn, the device must be "None"
            # In the case of Passcode the device is unimportant
            if preferred_factor in (DUO_UNIVERSAL_PROMPT_FACTOR_WEBAUTHN, DUO_UNIVERSAL_PROMPT_FACTOR_PASSCODE):
                preferred_device = "None"

            if preferred_device is None and preferred_factor not in (DUO_UNIVERSAL_PROMPT_FACTOR_WEBAUTHN, DUO_UNIVERSAL_PROMPT_FACTOR_PASSCODE):
                click.echo("No default authentication device configured.")
                preferred_device = click.prompt(
                    text=f'Please enter your desired authentication device (e.g. "phone1" with "{DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH}" or "{DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL}"), or "None" with "{DUO_UNIVERSAL_PROMPT_FACTOR_WEBAUTHN}" or "{DUO_UNIVERSAL_PROMPT_FACTOR_PASSCODE}"',
                    type=str,
                )

            # Trigger default authentication (call, push or WebAuthn with FIDO U2F / FIDO2 authenticator)
            signed_response = _perform_authentication_transaction(
                duo_url,
                sid,
                xsrf,
                preferred_factor,
                preferred_device,
                webauthn_supported,
                session,
                ssl_verification_enabled,
            )
            if signed_response == "cancelled":
                click.echo("Authentication method cancelled, aborting.")
                exit(-2)

        click.echo("Going for aws roles", err=True)
        return _retrieve_roles_page(
            roles_page_url,
            adfs_context,
            session,
            ssl_verification_enabled,
            signed_response,
        )

    return None, None, None


def _perform_authentication_transaction(
    duo_url,
    sid,
    xsrf,
    factor,
    device,
    webauthn_supported,
    session,
    ssl_verification_enabled,
):
    parsed = urlparse(duo_url)
    duo_host = f"{parsed.scheme}://{parsed.netloc}"

    txid = _begin_authentication_transaction(
        duo_host,
        sid,
        factor,
        device,
        webauthn_supported,
        session,
        ssl_verification_enabled,
    )

    txid = _verify_authentication_status(
        duo_host,
        sid,
        txid,
        session,
        ssl_verification_enabled,
    )
    if txid == "cancelled":
        return "cancelled"
    else:
        return _authentication_result(duo_host, sid, txid, factor, xsrf, session, ssl_verification_enabled)


def _context(html_response):
    context_query = './/input[@id="context"]'
    element = html_response.find(context_query)
    return element.get("value")


def _retrieve_roles_page(roles_page_url, context, session, ssl_verification_enabled, signed_response):
    logging.debug("context: {}".format(context))
    logging.debug("signed_response: {}".format(signed_response))

    html_response = ET.fromstring(signed_response.text, ET.HTMLParser())
    context = html_response.find('.//input[@name="context"]').get("value")
    duo_code = html_response.find('.//input[@name="duo_code"]').get("value")
    state = html_response.find('.//input[@name="state"]').get("value")
    authMethod = html_response.find('.//input[@name="authMethod"]').get("value")
    adfs_url = html_response.find('.//form[@class="adfs_form"]').get("action")

    data = {
        "duo_code": duo_code,
        "state": state,
        "context": context,
        "authMethod": authMethod,
    }
    response = session.post(
        adfs_url,
        verify=ssl_verification_enabled,
        headers=_headers,
        allow_redirects=True,
        data=data,
    )
    trace_http_request(response)

    if response.status_code != 200:
        raise click.ClickException("Issues during redirection to aws roles page. The error response {}".format(response))

    # Save session cookies to avoid having to repeat MFA on each login
    session.cookies.save(ignore_discard=True)

    html_response = ET.fromstring(response.text, ET.HTMLParser())
    return roles_assertion_extractor.extract(html_response)


def _authentication_result(duo_host, sid, txid, factor, xsrf, session, ssl_verification_enabled):
    # Detect new OIDC session
    oidc_sess = sid[0] if isinstance(sid, list) and len(sid) == 1 and isinstance(sid[0], _OidcSession) else None
    if oidc_sess is not None:
        return _oidc_finalize_auth(oidc_sess, session, ssl_verification_enabled)

    # Old frameless flow
    status_for_url = duo_host + "/frame/v4/status"
    data = {"sid": sid, "txid": txid}
    response = session.post(status_for_url, verify=ssl_verification_enabled, headers=_headers, data=data)
    trace_http_request(response)

    if response.status_code != 200:
        raise click.ClickException(
            "HTTP status code not 200 during UP retrieval of a code entered into the device."
            "The error response: {}".format(response)
        )

    json_response = response.json()
    if json_response["stat"] != "OK":
        raise click.ClickException(
            "'stat' not ok during UP retrieval of a code entered into the device."
            " The error response: {}".format(response.text)
        )

    if json_response["response"]["status_code"] != "allow":
        raise click.ClickException(
            "Response 'status_code' not 'allow' during UP retrieval of a code entered into the device."
            " The error response: {}".format(response.text)
        )

    return _load_duo_result_url(duo_host, sid, txid, factor, xsrf, session, ssl_verification_enabled)


def _oidc_finalize_auth(oidc_sess, session, ssl_verification_enabled):
    """New OIDC flow: GET /auth/finalize_auth → navigate to ADFS callback URL."""
    finalize_url = f"{oidc_sess.base_url}/auth/finalize_auth?authkey={oidc_sess.authkey}"
    response = session.get(finalize_url, verify=ssl_verification_enabled, headers=_headers)
    trace_http_request(response)
    logging.info(f"finalizeAuth: {response.status_code} {response.text[:500]}")

    if response.status_code != 200:
        raise click.ClickException(f"finalizeAuth failed: HTTP {response.status_code} {response.text[:200]}")

    resp_json = response.json()
    if resp_json.get("stat") != "OK":
        raise click.ClickException(f"finalizeAuth stat not OK: {response.text}")

    redirect_url = resp_json.get("response", {}).get("url")
    if not redirect_url:
        raise click.ClickException(f"No redirect URL in finalizeAuth response: {response.text}")

    logging.info(f"Navigating to ADFS callback: {redirect_url}")
    callback_response = session.get(redirect_url, verify=ssl_verification_enabled, allow_redirects=True)
    trace_http_request(callback_response)

    if callback_response.status_code != 200:
        raise click.ClickException(
            f"ADFS callback failed: HTTP {callback_response.status_code} URL: {callback_response.url}"
        )

    return callback_response


def _load_duo_result_url(duo_host, sid, txid, factor, xsrf, session, ssl_verification_enabled):
    result_for_url = duo_host + "/frame/v4/oidc/exit"
    data = {
        "sid": sid,
        "txid": txid,
        "factor": factor,
        "device_key": "",
        "_xsrf": xsrf or "",
        "dampen_choice": False,
    }
    response = session.post(result_for_url, verify=ssl_verification_enabled, headers=_headers, data=data)
    trace_http_request(response)

    if response.status_code != 200:
        raise click.ClickException(
            f"HTTP status code not 200 when following the Duo result URL after authentication. The error response {response} - {response.url} - {response.text}"
        )

    return response


def _verify_authentication_status(duo_host, sid, txid, session, ssl_verification_enabled):
    # Detect new OIDC session
    oidc_sess = sid[0] if isinstance(sid, list) and len(sid) == 1 and isinstance(sid[0], _OidcSession) else None
    if oidc_sess is not None:
        return _verify_oidc_push_status(oidc_sess, txid, session, ssl_verification_enabled)

    # Old frameless flow
    status_for_url = duo_host + "/frame/v4/status"

    responses = []
    while len(responses) < 10:
        data = {"sid": sid, "txid": txid}
        response = session.post(status_for_url, verify=ssl_verification_enabled, headers=_headers, data=data)
        trace_http_request(response)

        if response.status_code != 200:
            raise click.ClickException(
                "Issues during second factor verification. "
                "URL: {} Status: {} Response: {}".format(status_for_url, response.status_code, response.text[:500])
            )

        json_response = response.json()
        if json_response["stat"] != "OK":
            raise click.ClickException(
                "'stat' not OK during UP second factor verification. The error response: {}".format(response.text)
            )

        if json_response["response"]["status_code"] not in [
            "answered",
            "calling",
            "pushed",
            "webauthn_sent",
            "allow"
        ]:
            raise click.ClickException(
                "Bad 'status_code' during UP second factor verification. The error response: {}".format(response.text)
            )

        if json_response["response"]["status_code"] == "pushed":
            verification_code = json_response["response"].get("risk_based_factor_selection_data", {}).get("step_up_code")
            if verification_code:
                click.echo(
                    f"Verified Duo Push MFA code: {verification_code}",
                    err=True,
                )

        if json_response["response"]["status_code"] in ["pushed", "answered", "allow"]:
            return txid

        if (
            json_response["response"]["status_code"] == "webauthn_sent"
            and len(json_response["response"]["webauthn_credential_request_options"]) > 0
        ):
            webauthn_credential_request_options = json_response["response"]["webauthn_credential_request_options"]
            webauthn_credential_request_options["challenge"] = websafe_decode(webauthn_credential_request_options["challenge"])
            for cred in webauthn_credential_request_options["allowCredentials"]:
                cred["id"] = websafe_decode(cred["id"])
                cred.pop("transports", None)

            webauthn_session_id = webauthn_credential_request_options.pop("sessionId")

            devices = list(CtapHidDevice.list_devices())
            if CtapPcscDevice:
                devices.extend(list(CtapPcscDevice.list_devices()))

            if not devices:
                click.echo("No FIDO U2F / FIDO2 authenticator is eligible.")
                return "cancelled"

            threads = []
            webauthn_response = {"sessionId": webauthn_session_id}
            rq = queue.Queue()
            cancel = Event()
            for device in devices:
                t = Thread(
                    target=_webauthn_get_assertion,
                    args=(
                        device,
                        webauthn_credential_request_options,
                        duo_host,
                        sid,
                        webauthn_response,
                        session,
                        ssl_verification_enabled,
                        cancel,
                        rq,
                    ),
                )
                t.daemon = True
                threads.append(t)
                t.start()

            # Wait for first answer
            return rq.get()

        responses.append(response.text)

    raise click.ClickException("Number of responses exceeded during UP second factor verification. The responses: {}".format(responses))


def _verify_oidc_push_status(oidc_sess, push_txid, session, ssl_verification_enabled):
    """Poll /prompt/{akey}/auth/factors/push/status until SUCCESS or FAILURE."""
    for i in range(60):  # max 5 minutes (60 × 5s)
        status_url = (
            f"{oidc_sess.base_url}/auth/factors/push/status"
            f"?authkey={oidc_sess.authkey}&push_txid={push_txid}&saw_good_news=false"
        )
        response = session.get(status_url, verify=ssl_verification_enabled, headers=_headers)
        trace_http_request(response)
        logging.info(f"pushStatus [{i}]: {response.status_code} {response.text[:200]}")

        if response.status_code != 200:
            raise click.ClickException(f"Push status error: HTTP {response.status_code} {response.text[:200]}")

        resp_json = response.json()
        if resp_json.get("stat") != "OK":
            raise click.ClickException(f"Push status failed: {response.text}")

        result_obj = resp_json.get("response", {}).get("result", {})
        # result_obj is {"result": "SUCCESS"|"FAILURE"|"STATUS", ...}
        result = result_obj.get("result") if isinstance(result_obj, dict) else result_obj
        if result == "SUCCESS":
            return push_txid
        elif result == "FAILURE":
            raise click.ClickException(f"Duo Push authentication denied or timed out: {response.text}")

        time.sleep(5)

    raise click.ClickException("Push status polling timed out (5 minutes).")


def _webauthn_get_assertion(
    device,
    webauthn_credential_request_options,
    duo_host,
    sid,
    webauthn_response,
    session,
    ssl_verification_enabled,
    cancel,
    rq,
):
    click.echo(
        "Activate your FIDO U2F / FIDO2 authenticator now: '{}'".format(device),
        err=True,
    )
    client = Fido2Client(device, webauthn_credential_request_options["extensions"]["appid"])
    try:
        assertion = client.get_assertion(
            webauthn_credential_request_options,
            event=cancel,
        )
        authenticator_assertion_response = assertion.get_response(0)
        assertion_response = assertion.get_assertions()[0]

        webauthn_response["id"] = websafe_encode(assertion_response.credential["id"])
        webauthn_response["rawId"] = webauthn_response["id"]
        webauthn_response["type"] = assertion_response.credential["type"]
        webauthn_response["authenticatorData"] = websafe_encode(assertion_response.auth_data)
        webauthn_response["clientDataJSON"] = websafe_encode(authenticator_assertion_response["clientData"])
        webauthn_response["signature"] = binascii.hexlify(assertion_response.signature).decode("ascii")
        extension_results = authenticator_assertion_response["extensionResults"]
        if extension_results:
            webauthn_response["extensionResults"] = extension_results
        logging.debug("webauthn_response: {}".format(webauthn_response))

        click.echo(
            "Got response from FIDO U2F / FIDO2 authenticator: '{}'".format(device),
            err=True,
        )
        rq.put(_submit_webauthn_response(duo_host, sid, webauthn_response, session, ssl_verification_enabled))
    except Exception as e:
        logging.debug("Got an exception while waiting for {}: {}".format(device, e))
        if not cancel.is_set():
            raise
    finally:
        # Cancel the other FIDO U2F / FIDO2 prompts
        cancel.set()

        device.close()


_tx_pattern = re.compile(r"(TX\|[^:]+):APP.+")


def _tx(request_signature):
    m = _tx_pattern.search(request_signature)
    return m.group(1)


_app_pattern = re.compile(r".*(APP\|[^:]+)")


def _app(request_signature):
    m = _app_pattern.search(request_signature)
    return m.group(1)


def _initiate_authentication(
    duo_url,
    adfs_context,
    adfs_auth_method,
    roles_page_url,
    session,
    ssl_verification_enabled,
):
    data = {
        "adfs_context": adfs_context,
        "adfs_auth_method": adfs_auth_method,
    }
    response = session.post(
        duo_url,
        verify=ssl_verification_enabled,
        headers=_headers,
        allow_redirects=True,
        data=data,
    )
    trace_http_request(response)

    if response.status_code != 200 or response.url is None:
        return (None, None, None, None, None, None, None), False

    duo_url = response.url
    o = urlparse(duo_url)
    query = parse_qs(o.query)
    html_response = ET.fromstring(response.text, ET.HTMLParser())

    sid = query.get("sid")

    if sid is None:
        # New Duo URL format (/prompt/{ID}?authkey=...): sid is not in the URL query string.
        # The session is tracked via cookies; extract the sid from the auth-sid-c cookie.
        logging.debug(f"No sid in URL query params. Cookies: {session.cookies}")
        logging.debug(f"Response HTML (first 2000 chars): {response.text[:2000]}")
        auth_sid_raw = next((c.value for c in session.cookies if c.name == 'auth-sid-c'), '').strip('"')
        if auth_sid_raw:
            try:
                sid_b64 = auth_sid_raw.split('|')[0]
                sid_value = base64.b64decode(sid_b64).decode('utf-8')
                logging.info(f"Extracted sid from auth-sid-c cookie: {sid_value}")
                sid = [sid_value]
            except Exception as e:
                logging.debug(f"Failed to extract sid from auth-sid-c cookie: {e}")

        if sid is None:
            logging.info("No need for second factor authentification, "
                         "Duo directly returned the authentication cookie")
            return (None, None, None, None, None, _js_cookie(html_response), duo_url), True

    oidc_preferred_factor = None
    oidc_preferred_device = None
    oidc_xsrf = None
    non_interactive_finalize = None

    # Old flow: HTML contains a "tx" field requiring a second POST with browser fingerprint data.
    # New flow (/prompt/{ID}): no "tx" field, session already established via first POST + cookies.
    tx_element = html_response.find('.//input[@name="tx"]')
    if tx_element is not None:
        tx = tx_element.get("value")
        xsrf_element = html_response.find('.//input[@name="_xsrf"]')
        xsrf = xsrf_element.get("value") if xsrf_element is not None else ""

        data = {
            "tx": tx,
            "parent": "None",
            "_xsrf": xsrf,
            "java_version": "",
            "flash_version": "",
            "screen_resolution_width": "",
            "screen_resolution_height": "",
            "color_depth": "",
            "ch_ua_error": "",
            "client_hints": "",
            "is_cef_browser": "",
            "is_ipad_os": "",
            "is_ie_compatibility_mode": "",
            "is_user_verifying_platform_authenticator_available": "",
            "user_verifying_platform_authenticator_available_error": "",
            "acting_ie_version": "",
            "react_support": "",
            "react_support_error_message": "",
        }
        response = session.post(
            duo_url,
            verify=ssl_verification_enabled,
            headers=_headers,
            allow_redirects=True,
            data=data,
        )
        trace_http_request(response)
        for res in response.history:
            logging.info(f"history: {res} - {res.url}")

        # API BREAKING CHANGE. There's now a callback that has to happen here
        logging.info(f"duo_url: {duo_url}")
        logging.info(f"response.url: {response.url}")
        try:
            callback_response = session.post(
                response.url,
                verify=ssl_verification_enabled,
                headers=_headers,
                allow_redirects=True,
                params={"sid": sid, "tx": tx},
                data=data,
            )
            trace_http_request(callback_response)
            logging.info(f"Callback status: {callback_response.status_code} url: {callback_response.url}")
            content_type = callback_response.headers.get('content-type', '')
            logging.debug(f"Callback response content type: {content_type}")
            if 'application/json' in content_type:
                callback_json = callback_response.json()
                if callback_json["stat"] == "OK":
                    logging.info("Callback stat OK, using response.")
                    response = callback_response
                else:
                    logging.debug("Callback stat not OK, ignoring response.")
            else:
                logging.debug("Callback did not return json, ignoring response.")
        except Exception as e:
            logging.error("Error doing callback", exc_info=e)
            logging.error(f"ignoring: {e}")
        logging.info("Callback completed")

        html_response = ET.fromstring(response.text, ET.HTMLParser())
    else:
        logging.info("No 'tx' field in HTML — new Duo Universal Prompt OIDC flow")
        root_div = html_response.find('.//*[@id="pwl-prompt-root"]')
        authkey_attr = root_div.get('data-authkey') if root_div is not None else None
        akey_attr = root_div.get('data-akey') if root_div is not None else None
        logging.info(f"data-authkey: {authkey_attr}, data-akey: {akey_attr}")

        if authkey_attr and akey_attr:
            parsed = urlparse(duo_url)
            duo_host_str = f"{parsed.scheme}://{parsed.netloc}"

            # Step 1: GET /pre_authn/initialization to set up the pre-authn session
            init_url = f"{duo_host_str}/prompt/{akey_attr}/pre_authn/initialization?authkey={authkey_attr}&is_ipad=false"
            init_resp = session.get(init_url, verify=ssl_verification_enabled, headers=_json_headers)
            trace_http_request(init_resp)
            logging.info(f"pre_authn/initialization: status={init_resp.status_code} body={init_resp.text[:300]}")

            # Step 2: GET /pre_authn/evaluation to get available auth factors
            eval_url = (f"{duo_host_str}/prompt/{akey_attr}/pre_authn/evaluation"
                        f"?authkey={authkey_attr}&browser_features={_BROWSER_FEATURES}&local_trust_choice=undecided")
            eval_resp = session.get(eval_url, verify=ssl_verification_enabled, headers=_json_headers)
            trace_http_request(eval_resp)
            logging.info(f"pre_authn/evaluation: status={eval_resp.status_code} body={eval_resp.text[:800]}")

            push_pkey = None
            phone_pkey = None
            non_interactive_finalize = None
            if eval_resp.status_code == 200:
                try:
                    eval_json = eval_resp.json()
                    logging.info(f"pre_authn/evaluation full response: {eval_json}")
                    if eval_json.get("stat") == "OK":
                        resp = eval_json.get("response", {})
                        action = resp.get("action")
                        logging.info(f"pre_authn/evaluation action: {action}")

                        if action == "non_interactive_auth":
                            # Server approved auth without user interaction — call finalizeAuth directly
                            authz = resp.get("authz_evaluation", {})
                            if authz.get("is_allowed"):
                                logging.info("non_interactive_auth allowed — calling finalizeAuth directly")
                                oidc_sess = _OidcSession(authkey=authkey_attr, akey=akey_attr, host=duo_host_str)
                                sid = [oidc_sess]
                                non_interactive_finalize = _oidc_finalize_auth(oidc_sess, session, ssl_verification_enabled)
                            else:
                                logging.warning(f"non_interactive_auth but not allowed: {authz}")
                        else:
                            # Interactive auth: parse available_unified_auth_factors for push/phone pkeys
                            unified = resp.get("available_unified_auth_factors") or {}
                            factors = unified.get("factors") or resp.get("factors", [])
                            logging.info(f"Available factors: {factors}")
                            for factor in factors:
                                ft = factor.get("factor_type") or factor.get("type")
                                pkey = (
                                    factor.get("pkey")
                                    or (factor.get("device_info") or {}).get("pkey")
                                    or (factor.get("phone_info") or {}).get("pkey")
                                )
                                logging.info(f"Factor: type={ft} pkey={pkey} raw={factor}")
                                if ft == "push" and pkey and push_pkey is None:
                                    push_pkey = pkey
                                    logging.info(f"Push pkey: {push_pkey}")
                                elif ft == "phone_call" and pkey and phone_pkey is None:
                                    phone_pkey = pkey
                                    logging.info(f"Phone pkey: {phone_pkey}")
                    else:
                        logging.warning(f"pre_authn/evaluation stat not OK: {eval_json}")
                except Exception as e:
                    logging.warning(f"pre_authn/evaluation parse error: {e}", exc_info=True)
            else:
                logging.warning(f"pre_authn/evaluation HTTP {eval_resp.status_code}: {eval_resp.text[:300]}")

            if non_interactive_finalize is not None:
                pass  # sid and finalize response already set above
            elif push_pkey or phone_pkey:
                oidc_sess = _OidcSession(
                    authkey=authkey_attr,
                    akey=akey_attr,
                    host=duo_host_str,
                    push_pkey=push_pkey,
                    phone_pkey=phone_pkey,
                )
                sid = [oidc_sess]
                if push_pkey:
                    oidc_preferred_factor = DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH
                    oidc_preferred_device = "phone1"
                else:
                    oidc_preferred_factor = DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL
                    oidc_preferred_device = "phone1"
            else:
                logging.warning("No usable factors in pre_authn/evaluation — cannot authenticate")
        else:
            logging.warning("No data-authkey/data-akey in Duo prompt HTML")

    preferred_factor = _preferred_factor(html_response) or oidc_preferred_factor
    preferred_device = _preferred_device(html_response) or oidc_preferred_device
    webauthn_supported = _webauthn_supported(html_response)
    xsrf = _xsrf(html_response) or oidc_xsrf
    return (sid, xsrf, preferred_factor, preferred_device, webauthn_supported, non_interactive_finalize, duo_url), True


def _js_cookie(html_response):
    js_cookie_query = './/input[@name="js_cookie"]'
    element = html_response.find(js_cookie_query)
    return element is not None and element.get("value") or None


def _preferred_factor(html_response):
    preferred_factor_query = './/input[@name="preferred_factor"]'
    element = html_response.find(preferred_factor_query)
    return element is not None and element.get("value") or None


def _preferred_device(html_response):
    preferred_device_query = './/input[@name="preferred_device"]'
    element = html_response.find(preferred_device_query)
    return element is not None and element.get("value") or None


def _webauthn_supported(html_response):
    webauthn_supported_query = './/option[@name="webauthn"]'
    elements = html_response.findall(webauthn_supported_query)
    return len(elements) > 0


def _xsrf(html_response):
    xsrf_query = './/input[@name="_xsrf"]'
    element = html_response.find(xsrf_query)
    return element is not None and element.get("value") or None


def _begin_authentication_transaction(
    duo_host,
    sid,
    preferred_factor,
    preferred_device,
    webauthn_supported,
    session,
    ssl_verification_enabled,
):
    # Detect new OIDC session
    oidc_sess = sid[0] if isinstance(sid, list) and len(sid) == 1 and isinstance(sid[0], _OidcSession) else None
    if oidc_sess is not None:
        return _begin_oidc_authentication(oidc_sess, preferred_factor, session, ssl_verification_enabled)

    # Old frameless flow
    duo_url = duo_host + "/frame/v4/prompt"

    click.echo(
        "Triggering authentication method: '{}' with '{}'".format(preferred_factor, preferred_device),
        err=True,
    )

    data = {
        "sid": sid,
        "factor": preferred_factor,
        "device": preferred_device,
    }

    # Prompt for a passcode?
    if preferred_factor == DUO_UNIVERSAL_PROMPT_FACTOR_PASSCODE:
        passcode = None
        while not passcode or not re.match(r'^[0-9]{6,}$', passcode):
            passcode = click.prompt('Enter passcode (6+ digit number)', hide_input=True)
        data['passcode'] = passcode
        data['device'] = 'None'

    response = session.post(duo_url, verify=ssl_verification_enabled, headers=_headers, data=data)
    trace_http_request(response)

    if response.status_code != 200:
        raise click.ClickException(
            "Issues during beginning of the authentication process. "
            "URL: {} Status: {} Response: {}".format(duo_url, response.status_code, response.text[:500])
        )

    json_response = response.json()
    if json_response["stat"] != "OK":
        raise click.ClickException("Cannot begin authentication process. The error response: {}".format(response.text))

    return json_response["response"]["txid"]


def _begin_oidc_authentication(oidc_sess, factor, session, ssl_verification_enabled):
    """New Duo Universal Prompt OIDC: initiate push or phone call."""
    click.echo(f"Triggering authentication method: '{factor}' (new OIDC flow)", err=True)

    pkey = oidc_sess.pkey_for_factor(factor)
    if pkey is None:
        raise click.ClickException(
            f"Factor '{factor}' not available in this Duo session. "
            f"Available: {'Duo Push' if oidc_sess.push_pkey else ''} "
            f"{'Phone Call' if oidc_sess.phone_pkey else ''}"
        )

    if factor == DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH:
        push_url = f"{oidc_sess.base_url}/auth/factors/push/auth"
        body = {"authkey": oidc_sess.authkey, "pkey": pkey, "otp_code": None}
        response = session.post(push_url, verify=ssl_verification_enabled, headers=_json_headers, json=body)
        trace_http_request(response)
        logging.info(f"initiatePush: {response.status_code} {response.text[:300]}")
        if response.status_code != 200:
            raise click.ClickException(f"Failed to initiate Duo Push: HTTP {response.status_code} {response.text[:200]}")
        resp_json = response.json()
        if resp_json.get("stat") != "OK":
            raise click.ClickException(f"Duo Push initiation failed: {response.text}")
        push_txid = resp_json.get("response", {}).get("push_txid")
        if not push_txid:
            raise click.ClickException(f"No push_txid in initiatePush response: {response.text}")
        step_up_code = resp_json.get("response", {}).get("step_up_code")
        if step_up_code:
            click.echo(f"Duo step-up code: {step_up_code}", err=True)
        return push_txid

    elif factor == DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL:
        phone_url = f"{oidc_sess.base_url}/auth/factors/phone_call"
        body = {"authkey": oidc_sess.authkey, "pkey": pkey}
        response = session.post(phone_url, verify=ssl_verification_enabled, headers=_json_headers, json=body)
        trace_http_request(response)
        logging.info(f"initiatePhoneCall: {response.status_code} {response.text[:300]}")
        if response.status_code != 200:
            raise click.ClickException(f"Failed to initiate Phone Call: HTTP {response.status_code} {response.text[:200]}")
        resp_json = response.json()
        if resp_json.get("stat") != "OK":
            raise click.ClickException(f"Phone Call initiation failed: {response.text}")
        # Phone call returns a txid in response
        txid = resp_json.get("response", {}).get("txid") or resp_json.get("response", {}).get("push_txid")
        if not txid:
            raise click.ClickException(f"No txid in phone call response: {response.text}")
        return txid

    else:
        raise click.ClickException(
            f"Factor '{factor}' is not yet supported in the new Duo OIDC flow. "
            f"Please use '{DUO_UNIVERSAL_PROMPT_FACTOR_DUO_PUSH}' or '{DUO_UNIVERSAL_PROMPT_FACTOR_PHONE_CALL}'."
        )


def _submit_webauthn_response(duo_host, sid, webauthn_response, session, ssl_verification_enabled):
    prompt_for_url = duo_host + "/frame/v4/prompt"

    data = {
        "sid": sid,
        "device": "webauthn_credential",
        "factor": "webauthn_finish",
        "response_data": json.dumps(webauthn_response),
    }
    response = session.post(prompt_for_url, verify=ssl_verification_enabled, headers=_headers, data=data)
    trace_http_request(response)

    if response.status_code != 200:
        raise click.ClickException(
            "Issues during submitting WebAuthn response for the authentication process. The error response {}".format(response)
        )

    json_response = response.json()
    if json_response["stat"] != "OK":
        raise click.ClickException("Cannot complete authentication process. The error response: {}".format(response.text))

    return json_response["response"]["txid"]


def _duo_url(html_response):
    duo_url_query = './/form[@id="adfs_form"]/@action'
    return html_response.xpath(duo_url_query)[0]


def _adfs_context(html_response):
    adfs_context_query = './/form[@id="adfs_form"]/input[@name="adfs_context"]/@value'
    return html_response.xpath(adfs_context_query)[0]


def _adfs_auth_method(html_response):
    adfs_auth_method_query = './/form[@id="adfs_form"]/input[@name="adfs_auth_method"]/@value'
    return html_response.xpath(adfs_auth_method_query)[0]


def _action_url_on_validation_success(html_response):
    duo_auth_method = './/form[@id="options"]'
    element = html_response.find(duo_auth_method)
    return element.get("action")
